# Blog-backend 




## Table of contents

- [General info](#general-info)
- [Technologies](#technologies)
- [Setup](#setup)

## General info

This project is simple Lorem ipsum dolor generator.

## Technologies

Project is created with:

- NPM version: 6.14.13
- Node version: v14.17.3

## Setup project


To run this project, install it locally using github and yarn:

```
$ git clone https://github.com/evairo176/Blog-backend.git
$ yarn add nodemon
$ yarn server

```

## Contribution 

- Name: Dicki Prasetya
- Email: dickiprasetya176@gmail.com
- Linkedln: https://www.linkedin.com/in/dicki-prasetya-3a7587195/


